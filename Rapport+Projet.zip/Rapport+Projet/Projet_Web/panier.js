$("#panier").fancybox({
        
        'autoDimensions' : false,
        'width'             : '70%',
        'height'            : '70%',
        'autoScale'         : false,
        'transitionIn'      : 'elastic',
        'transitionOut'     : 'elastic',
        'type'              : 'iframe'
        
    });